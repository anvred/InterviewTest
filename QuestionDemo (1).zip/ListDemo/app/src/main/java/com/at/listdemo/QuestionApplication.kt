package com.at.listdemo

import android.app.Application
import android.content.Context
import com.at.listdemo.di.appModule
import com.at.listdemo.di.repoModule
import com.at.listdemo.di.viewModelModule
import org.koin.android.ext.koin.androidContext
import org.koin.android.ext.koin.androidLogger
import org.koin.core.context.startKoin
import org.koin.core.module.Module


class QuestionApplication : Application() {
    companion object {
        lateinit var context: Context
    }

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
    }

    override fun onCreate() {
        super.onCreate()
        context = this
        startKoin {
            androidLogger()
            androidContext(this@QuestionApplication)
            modules(getModule())
        }

    }


    private fun getModule(): List<Module> {
        return listOf(appModule, viewModelModule, repoModule)
    }
}