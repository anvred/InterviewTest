package com.at.listdemo.api

import com.at.listdemo.model.QuestionListResp
import kotlinx.coroutines.Deferred
import retrofit2.Response
import retrofit2.http.*

interface ApiServices {

    @GET(ApiConstants.LIST_URL)
    fun getList(
        @Query("amount") amount: Int,
        @Query("category") category: Int
    ): Deferred<Response<QuestionListResp>>

}