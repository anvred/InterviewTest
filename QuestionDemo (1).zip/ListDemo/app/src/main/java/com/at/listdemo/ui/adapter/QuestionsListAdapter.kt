package com.at.listdemo.ui.adapter

import android.annotation.SuppressLint
import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.core.text.HtmlCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.at.listdemo.R
import com.at.listdemo.databinding.ListitemQuizresultBinding

class QuestionsListAdapter(val activity: Activity) :
    RecyclerView.Adapter<QuestionsListAdapter.MyViewHolder>() {

    var list: List<com.at.listdemo.model.Result> = listOf()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {

        val binding = DataBindingUtil.inflate(
            activity.layoutInflater, R.layout.listitem_quizresult,
            null, false
        ) as ListitemQuizresultBinding

        return MyViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        bindData(holder, position)
    }

    private fun bindData(holder: MyViewHolder, position: Int) {
//        optionsLayoutClearColor(holder)
        radioOptionBtnEnable(holder, false)
        val question_order_number: Int = position + 1
        holder.txt_questionindex?.text = "$question_order_number. Question"
        holder.txt_main_question?.text = HtmlCompat.fromHtml(list[position].question, 0)
        holder.btn_radio1?.text = HtmlCompat.fromHtml(list[position].correct_answer,0)
        holder.layout_radio1?.visibility = View.VISIBLE
        for (i in list[position].incorrect_answers.indices) {
            when (i) {
                0 -> {
                    holder.layout_radio2?.visibility = View.VISIBLE
                    holder.btn_radio2?.text = HtmlCompat.fromHtml(list[position].incorrect_answers[0],0)
                }
                1 -> {
                    holder.layout_radio3?.visibility = View.VISIBLE
                    holder.btn_radio3?.text = HtmlCompat.fromHtml(list[position].incorrect_answers[1],0)
                }
                2 -> {
                    holder.layout_radio4?.visibility = View.VISIBLE
                    holder.btn_radio4?.text = HtmlCompat.fromHtml(list[position].incorrect_answers[2],0)
                }
            }
        }
    }

    private fun radioOptionBtnEnable(holder: MyViewHolder, enabled: Boolean) {
        holder.layout_radio1?.visibility = View.GONE
        holder.layout_radio2?.visibility = View.GONE
        holder.layout_radio3?.visibility = View.GONE
        holder.layout_radio4?.visibility = View.GONE
    }

    @SuppressLint("NotifyDataSetChanged")
    fun setListItems(animList: List<com.at.listdemo.model.Result>) {
        this.list = animList;
        notifyDataSetChanged()
    }

    class MyViewHolder(itemView: ListitemQuizresultBinding?) :
        RecyclerView.ViewHolder(itemView?.root!!) {
        val txt_questionindex: TextView? = itemView?.txtQuestionindex
        var txt_main_question: TextView? = itemView?.txtMainQuestion
        var txt_subquestion_msg: TextView? = itemView?.txtQuestionindex
        val layout_radio1: RelativeLayout? = itemView?.layoutRadio1
        var layout_radio2: RelativeLayout? = itemView?.layoutRadio2
        var layout_radio3: RelativeLayout? = itemView?.layoutRadio3
        var layout_radio4: RelativeLayout? = itemView?.layoutRadio4
        val btn_radio1: RadioButton? = itemView?.btnRadio1
        var btn_radio2: RadioButton? = itemView?.btnRadio2
        var btn_radio3: RadioButton? = itemView?.btnRadio3
        var btn_radio4: RadioButton? = itemView?.btnRadio4
        val txt_correct: TextView? = itemView?.txtCorrect
        val txt_correct_msg: TextView? = itemView?.txtCorrectMsg

    }
}