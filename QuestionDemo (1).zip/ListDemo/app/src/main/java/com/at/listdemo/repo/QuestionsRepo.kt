package com.at.listdemo.repo

import androidx.lifecycle.MutableLiveData
import com.at.listdemo.api.ApiResponse
import com.at.listdemo.api.ApiServices
import com.at.listdemo.api.DataFetchCall
import com.at.listdemo.model.QuestionListResp
import kotlinx.coroutines.Deferred
import org.koin.core.KoinComponent
import retrofit2.Response

class QuestionsRepo constructor(
    private val apiServices: ApiServices,
) : KoinComponent  {

    fun executeGetQuestion(
        amount: Int,
        category: Int,
        resposne: MutableLiveData<ApiResponse<QuestionListResp>>
    )
    {
        object : DataFetchCall<QuestionListResp>(resposne)
        {
            override fun shouldFetchLocally(): Boolean {
                return false             }

            override fun loadLocally(): QuestionListResp? {
               return null
            }

            override fun createCallAsync(): Deferred<Response<QuestionListResp>> {
            return apiServices.getList(amount,category)}

            override fun saveResult(result: QuestionListResp) {
            }

        }.execute()
    }

}