package com.at.listdemo.api

class ApiConstants {
    companion object {
        const val BASE_URL = "https://opentdb.com/"
        const val LIST_URL = "api.php"

        const val API_TIME_OUT: Long = 15000

    }
}