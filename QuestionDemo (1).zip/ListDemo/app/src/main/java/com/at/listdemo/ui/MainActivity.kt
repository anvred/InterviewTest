package com.at.listdemo.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.at.listdemo.R
import com.at.listdemo.api.ApiResponse
import com.at.listdemo.databinding.ActivityMainBinding
import com.at.listdemo.model.QuestionListResp
import com.at.listdemo.ui.adapter.QuestionsListAdapter
import com.at.listdemo.viewmodel.QuestionViewModel
import org.koin.android.ext.android.inject

class MainActivity : AppCompatActivity() {
    lateinit var adapter: QuestionsListAdapter
    private lateinit var binding: ActivityMainBinding
    private val viewModel: QuestionViewModel by inject()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding =
            DataBindingUtil.setContentView(this, R.layout.activity_main) as ActivityMainBinding
        initUI()
        hitApi(5, 12)

    }

    private fun initUI() {
        adapter = QuestionsListAdapter(this)
        binding.recyclerview.layoutManager = LinearLayoutManager(this)
        binding.recyclerview.adapter = adapter
    }

    //region API hit and Handling
    fun hitApi(
        amount: Int,
        category: Int
    ) {
        viewModel.executeAnimsResponse(amount, category)
        viewModel.response.observe(this, surveyObserver)
    }

    private val surveyObserver: Observer<ApiResponse<QuestionListResp>> by lazy {
        Observer<ApiResponse<QuestionListResp>> {

            when (it.status) {
                ApiResponse.Status.SUCCESS -> {
                    if (it.data != null) {
                        adapter.setListItems(it.data.results)
                    }
                }

                ApiResponse.Status.ERROR -> {

                }

                ApiResponse.Status.LOADING -> {

                }
            }
        }
    }

}