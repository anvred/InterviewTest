package com.at.listdemo.di


import com.at.listdemo.QuestionApplication
import com.at.listdemo.viewmodel.QuestionViewModel
import org.koin.android.ext.koin.androidApplication
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module


val viewModelModule = module {
    viewModel { QuestionViewModel(androidApplication() as QuestionApplication, get()) }

}