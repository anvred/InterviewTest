package com.at.listdemo.api


import androidx.lifecycle.MutableLiveData
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import retrofit2.Response


abstract class DataFetchCall<ResultType>(private val responseLiveData: MutableLiveData<ApiResponse<ResultType>>) {


    abstract fun createCallAsync(): Deferred<Response<ResultType>>
    abstract fun saveResult(result: ResultType)
    abstract fun shouldFetchLocally(): Boolean
    abstract fun loadLocally(): ResultType?

    fun execute() {
        if (shouldFetchLocally()) {
            GlobalScope.launch {
                try {
                    responseLiveData.postValue(ApiResponse.loading())
                    val request = async {
                        return@async loadLocally()
                    }
                    val response = request.await()
                    if (response != null) {
                        responseLiveData.postValue(ApiResponse.success(response))
                    } else
                        responseLiveData.postValue(
                            ApiResponse.error(
                                Throwable("Error")
                            )
                        )
                } catch (exception: Exception) {
                    responseLiveData.postValue(ApiResponse.error(exception))
                }
            }
        } else {
            GlobalScope.launch {
                try {
                    responseLiveData.postValue(ApiResponse.loading())
                    val request = createCallAsync()
                    val response = request.await()
                    if (response.body() != null) {
                        saveResult(response.body()!!)
                        responseLiveData.postValue(ApiResponse.success(response.body()!!))
                    } else {
                        responseLiveData.postValue(ApiResponse.error(Throwable(response.errorBody().toString())))
                    }
                } catch (exception: Exception) {
                    responseLiveData.postValue(ApiResponse.error(exception))
                }
            }
        }
    }

}