package com.at.listdemo.di

import com.at.listdemo.repo.QuestionsRepo
import org.koin.dsl.module


val repoModule = module {
    single { QuestionsRepo(get()) }

}