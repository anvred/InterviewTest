package com.at.listdemo.viewmodel

import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.at.listdemo.QuestionApplication
import com.at.listdemo.api.ApiResponse
import com.at.listdemo.model.QuestionListResp
import com.at.listdemo.repo.QuestionsRepo
import org.koin.core.KoinComponent

class QuestionViewModel constructor(
    app: QuestionApplication,
    private val questionsRepo: QuestionsRepo
) : AndroidViewModel(app), KoinComponent {

    var arrayList = ArrayList<com.at.listdemo.model.Result>()
    var response = MutableLiveData<ApiResponse<QuestionListResp>>()


    fun executeAnimsResponse(
        amount: Int,
        category: Int
    ) {
        return questionsRepo.executeGetQuestion(
            amount,
            category, response
        )
    }

    fun setAnimList(list: ArrayList<com.at.listdemo.model.Result>) {
        arrayList.clear()
        arrayList.addAll(list)
    }

}